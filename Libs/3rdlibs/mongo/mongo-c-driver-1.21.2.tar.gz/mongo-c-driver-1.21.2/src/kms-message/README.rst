This Repository is NOT a supported MongoDB product

kms-message
===========

Library to generate Amazon Web Services Key Management Service (KMS) requests.
This library is *not* a complete implementation of a KMS client, it only
implements the request format.
